let js = "entering";
if (js === "entering") alert("Invortory IT assets");

let logIn = {
  emailaddress: "Sanyalameriah.com",
  password: "12345678910",
};
console.log(logIn["emailaddress"]);
console.log(logIn["password"]);

let names = ["Ahmed", "Maria", "Waseem", "Abdulaziz"];
console.log(names);
// task
function Hello(name, lastName) {
  console.log("Hello" + name + " " + lastName);
}
Hello("Ahmed");
Hello("Maria");
Hello("Waseem");
Hello("Abdulaziz");
